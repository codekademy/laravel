<?php $__env->startSection('title', 'WPBlog | Blog index'); ?>

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>
                Blog
                <small>Display All blog posts</small>
            </h1>
            <ol class="breadcrumb">
                <li>
                    <a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
                </li>
                <li><a href="<?php echo e(route('blog.index')); ?>">Blog</a></li>
                <li class="active">All Posts</li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header">
                            <div class="pull-left">
                                <a href="<?php echo e(route('blog.create')); ?>" class="btn btn-success">Add New</a>
                            </div>
                        </div>
                        <!-- /.box-header -->
                        <div class="box-body ">
                            <?php if(! $posts->count()): ?>
                                <div class="alert alert-danger">
                                    <strong>No record found</strong>
                                </div>
                            <?php else: ?>

                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <td width="80">Action</td>
                                        <td>Title</td>
                                        <td width="120">Author</td>
                                        <td width="150">Category</td>
                                        <td width="170">Date</td>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('blog.edit', $post->id)); ?>" class="btn btn-xs btn-default">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                                <a href="<?php echo e(route('blog.destroy', $post->id)); ?>" class="btn btn-xs btn-danger">
                                                    <i class="fa fa-times"></i>
                                                </a>
                                            </td>
                                            <td><?php echo e($post->title); ?></td>
                                            <td><?php echo e($post->author->name); ?></td>
                                            <td><?php echo e($post->category->title); ?></td>
                                            <td>
                                                <abbr title="<?php echo e($post->dateFormatted(true)); ?>"><?php echo e($post->dateFormatted()); ?></abbr> |
                                                <?php echo $post->publicationLabel(); ?>

                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                            </div>
                            <!-- /.box-body -->
                            <div class="box-footer clearfix">
                                <div class="pull-left">
                                    <?php echo e($posts->render()); ?>

                                </div>
                                <div class="pull-right">
                                    <?php //$postCount = $posts->count() ?>
                                    <small><?php echo e($postCount); ?> <?php echo e(str_plural('Item', $postCount)); ?></small>
                                </div>
                            </div>
                    </div>
                    <!-- /.box -->
                </div>
            </div>
            <!-- ./row -->
        </section>
        <!-- /.content -->
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $('ul.pagination').addClass('no-margin pagination-sm');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>