<?php $__env->startSection('content'); ?>
    <div class="login-box">
        <div class="login-logo">
            <a href="/"><b>{WP</b>BLOG<b>}</b></a>
        </div>
        <!-- /.login-logo -->
        <div class="login-box-body">
            <p class="text-center">Welocome KICSUET!</p>
            <p class="login-box-msg">Sign in to start your session</p>

            <form method="POST" action="<?php echo e(url('/login')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?> has-feedback">
                    <input type="email" class="form-control" placeholder="Email" name="email" value="<?php echo e(old('email')); ?>">
                    <span class="fa fa-envelope form-control-feedback"></span>

                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
                    <?php endif; ?>
                </div>
                <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?> has-feedback">
                    <input type="password" class="form-control" placeholder="Password" name="password">
                    <span class="fa fa-lock form-control-feedback"></span>

                    <?php if($errors->has('password')): ?>
                        <span class="help-block">
                <strong><?php echo e($errors->first('password')); ?></strong>
            </span>
                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-xs-8">
                        
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" name="remember"> Remember Me
                            </label>
                        </div>
                    </div>
                    <!-- /.col -->
                    <div class="col-xs-4">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
                    </div>
                    <!-- /.col -->
                </div>
            </form>

            <br>
            <a href="<?php echo e(url('/password/reset')); ?>">I forgot my password</a><br>
            <p class="text-center"><br><strong>Trainer: Tahir Shafi | +923341068817</strong></p>
        </div>
        <!-- /.login-box-body -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>