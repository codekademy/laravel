<?php

namespace App\Http\Controllers;
use App\Category;
use App\Post;
use App\User;
use Illuminate\Http\Request;
use Carbon\Carbon;

class BlogController extends Controller
{
    protected $limit = 3;
    public function index()
    {

        $categories = Category::with(['posts' => function($query){
            $query->published();
        }])->orderBy('title', 'asc')->get();

        $posts = Post::with('author')
            ->latestFirst()
            ->published()
            ->simplePaginate($this->limit);
        return view('blog.index', compact('posts', 'categories'));
    }

    public function category(Category $category)
    {
        $categoryName = $category->title;

        $categories = Category::with(['posts' => function($query){
            $query->published();
        }])->orderBy('title', 'asc')->get();


        $posts = $category->posts()
            ->with('author')
            ->latestFirst()
            ->published()
            ->simplePaginate($this->limit);
        return view('blog.index', compact('posts', 'categories', 'categoryName'));

    }

    public function author(User $author)
    {
        $authorName = $author->name;

        $categories = Category::with(['posts' => function($query){
            $query->published();
        }])->orderBy('title', 'asc')->get();

        $posts = $author->posts()
            ->with('category')
            ->latestFirst()
            ->published()
            ->simplePaginate($this->limit);

        return view("blog.index", compact('posts', 'authorName', 'categories'));
    }

    public function show(Post $post)
    {
        $categories = Category::with(['posts' => function($query){
            $query->published();
        }])->orderBy('title', 'asc')->get();

        return view("blog.show", compact('post', 'categories'));
    }
}
